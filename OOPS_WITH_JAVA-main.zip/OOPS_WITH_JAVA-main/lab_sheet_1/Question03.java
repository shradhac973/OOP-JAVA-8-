import java.util.Scanner;

// Check whether an integer is even or odd using the modulus operator.
// Sample input:
// 12
// Sample output:
// 12 is even.
public class Question03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int number = input.nextInt();

        if (number % 2 == 0) {
            System.out.println(number + " is even.");
        } else {
            System.out.println(number + " is odd.");
        }
    }
}