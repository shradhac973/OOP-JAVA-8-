package lab_sheet_9.Q17;

import java.util.TreeSet;

public class TreeSetSort {
    public static void main(String[] args) {
        TreeSet<Integer> numbers = new TreeSet<>();
        numbers.add(40);
        numbers.add(10);
        numbers.add(30);
        numbers.add(20);

        System.out.println("Sorted set: " + numbers);
    }
}
